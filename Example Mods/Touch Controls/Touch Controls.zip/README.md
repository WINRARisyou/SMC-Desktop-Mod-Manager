# Authors
- WINRARisyou
# Description
This mod has a folder (TouchControls) that has assets that aren't in the original game. That's right, you can add assets that aren't in the original game! It's a bit niche as there isn't really any easy way to integrate them into the game, but in this case with touch controls (separate html elements), you can add them.
